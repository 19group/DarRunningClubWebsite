<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div class="" id="menu">
	  <div class="w3-bar w3-white w3-wide w3-padding w3-card">
	    <a href="#home" class="text-muted w3-bar-item w3-button"><b>Logo</b></a>
	    <!-- Float links to the right. Hide them on small screens -->
	    <div class="links w3-hide-small">
	      <a class="w3-bar-item w3-button"></a>
	      <a href="#projects" class="w3-bar-item w3-button">Race & Events</a>
	      <a href="#about" class="w3-bar-item w3-button">About Us</a>
	      <a href="#contact" class="w3-bar-item text-danger w3-button">Clubs</a>
	      <a href="#contact" class="w3-bar-item w3-button">Join</a>
	      <a href="#contact" class="w3-bar-item w3-button">Contact Us</a>
	    </div>
	  </div>
	</div>

</body>
</html>
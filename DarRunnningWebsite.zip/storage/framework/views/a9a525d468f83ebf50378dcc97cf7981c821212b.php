<?php $__env->startSection('page'); ?>

<div class="container-fluid">
	<h3>Archievements</h3>
	<hr>

	<div class="col-md-6">

		<form action="<?php echo e(route('homepageUpdate', [ 'exp' => $achievements->experience ])); ?>" method="post">
            <?php echo e(csrf_field()); ?>


			<div class="col-md-4 form-group">
				<input class="form-control" type="number" name="years" required>
				<p class="text-center">Years of achievements</p>
			</div>
			<div class="col-md-4 form-group">
				<input class="form-control" type="number" name="marathons" required>
				<p class="text-center">Annual Marathons</p>
			</div>
			<div class="col-md-4 form-group">
				<input class="form-control" type="number" name="medals" required>
				<p class="text-center">Won Medals</p>
			</div>
			<div class="col-md-4 form-group">
				<button class="btn btn-info">Update</button>
			</div>

		</form>
	</div>

	 <div class="col-md-6">
	    <div class="col-md-8 col-md-offset-2 text-center">
	      <div class="container-fluid text-center">
	      <div class="col-md-4 text-center">
	        <h1><?php echo e($achievements->experience); ?></h1>
	        <p>YEARS OF<br>EXPERIENCE</p>
	      </div>
	      <div class="col-md-4 text-center">
	        <h1><?php echo e($achievements->marathons); ?></h1>
	        <p>ANNUAL<br>MARATHONS</p>
	      </div>
	      <div class="col-md-4 text-center">
	        <h1><?php echo e($achievements->medals); ?></h1>
	        <p>WON<br>MEDALS</p>
	      </div>
	    </div><br><br>
	   </div>
  </div>

	<div class="col-md-12 p-3">

		<h3>Runs</h3>
		<hr>

	  <div class="col-md-6">

			<form action="<?php echo e(route('runsUpdate')); ?>" method="post">

	            <?php echo e(csrf_field()); ?>


	            <div class="container-fluid">
	            	<div class="col-md-6">
						<div class="col-md-12 form-group">
							<input class="form-control" type="text" name="title" required placeholder="starts-ends">
							<p class="text-center">Title</p>
						</div>
						<div class="col-md-12 form-group">
							<input class="form-control" type="text" name="area" required>
							<p class="text-center">Area</p>
						</div>
						<div class="col-md-12 form-group">
							<input class="form-control" type="number" name="members" required>
							<p class="text-center">Members</p>
						</div>
					</div>

					<div class="col-md-6">
						<div class="col-md-12 form-group">
							<textarea class="form-control" name="schedules" placeholder="Mon-Fri 4:00-6:00 &#10;Sat-Sun 3:00-6:00"></textarea>
							<p class="text-center">Schedule</p>
						</div>
						<div class="col-md-12 form-group">
							<input class="form-control" type="text" name="contact" required>
							<p class="text-center">Contact</p>
						</div>
						
					</div>

				</div>
					<div class="col-md-12 form-group">
						<button class="btn pull-right btn-info">Update</button>
					</div>
			</form>

		</div>


		<div class="col-md-6">
			<table class="table table-stripe table-responsive">
				<tr><th>Title</th><th>Area</th><th>Members</th><th>Shedules</th><th>Contact</th></tr>

			<?php $__currentLoopData = $runs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr><td><?php echo e($run->title); ?></td><td><?php echo e($run->area); ?></td><td><?php echo e($run->members); ?></td><td><?php echo nl2br($run->schedules); ?></td><td><?php echo e($run->contact); ?></td></tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</table>
	  	</div>

	</div>




</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
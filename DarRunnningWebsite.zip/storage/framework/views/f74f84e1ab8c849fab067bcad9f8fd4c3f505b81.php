<?php $__env->startSection('page'); ?>

<div class="container-fluid">
	<h3>Create Post for News & Events Page</h3>
	<hr>

	<div class="col-md-6">

		<form action="<?php echo e(route('createPost', ['creater'=> Auth::user()->name] )); ?>" method="post">
            <?php echo e(csrf_field()); ?>


			<div class="col-md-12 form-group">
				<input class="form-control" type="text" name="title" required placeholder="Heading">
			</div>
			<div class="col-md-12 form-group">
				<input class="form-control" type="text" name="sub_title" required placeholder="Sub-heading">
			</div>
			<div class="col-md-12 form-group">
				<textarea class="form-control" required name="content" placeholder="content"></textarea>
			</div>
			<div class="col-md-12 form-group">
				<button class="btn col-md-4 pull-right btn-info">Post</button>
			</div>

		</form>
	</div>

	<div class="col-md-6">
		
		 <div class="col-md-12">
	        <div class="row post_head rounded-top d-flex ">
	          <span class="p-2 post-head"><?php echo e($post->title); ?></span>
	          <span class="p-2 text-muted"><?php echo e($post->created_at->diffForHumans()); ?></span>
	          <div class="ml-auto p-2"><sup>by &nbsp;&nbsp;</sup><?php echo e($post->user); ?></div>
	        </div>

	        <div class="content row p-3 border">

	          <span class="post-subhead text-muted"><i><?php echo e($post->sub_title); ?></i></span>

	          <br><br>
	          
	          <?php echo nl2br($post->post_content); ?>


	        </div>
      </div>
      <div class="col-md-12">
      	<h5 class="text-muted pull-right"><i>Latest post</i></h5>
      </div>

	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
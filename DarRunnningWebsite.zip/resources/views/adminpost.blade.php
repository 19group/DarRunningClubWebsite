@extends('admin')
@section('page')

<div class="container-fluid">
	<h3>Create Post</h3>
	<hr>

	<div class="col-md-6">

		<form action="{{ route('createPost', ['creater'=> Auth::user()->name] ) }}" method="post">
            {{ csrf_field() }}

			<div class="col-md-12 form-group">
				<input class="form-control" type="text" name="title" required placeholder="Heading">
			</div>
			<div class="col-md-12 form-group">
				<input class="form-control" type="text" name="sub_title" required placeholder="Sub-heading">
			</div>
			<div class="col-md-12 form-group">
				<textarea class="form-control" required name="content" placeholder="content"></textarea>
			</div>
			<div class="col-md-12 form-group">
				<button class="btn col-md-4 pull-right btn-info">Post</button>
			</div>

		</form>
	</div>

	<div class="col-md-6">
		
		 <div class="col-md-12">
	        <div class="row post_head rounded-top d-flex ">
	          <span class="p-2 post-head">{{ $post->title }}</span>
	          <span class="p-2 text-muted">{{ $post->created_at->diffForHumans() }}</span>
	          <div class="ml-auto p-2"><sup>by &nbsp;&nbsp;</sup>{{ $post->user }}</div>
	        </div>

	        <div class="content row p-3 border">

	          <span class="post-subhead text-muted"><i>{{ $post->sub_title }}</i></span>

	          <br><br>
	          
	          {!! nl2br($post->post_content) !!}

	        </div>
      </div>
      <div class="col-md-12">
      	<h5 class="text-muted pull-right"><i>Latest post</i></h5>
      </div>

	</div>
</div>



@endsection
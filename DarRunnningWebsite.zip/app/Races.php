<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Races extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Runs extends Model
{
    //
    protected $fillable = ['title', 'area', 'members', 'schedules', 'contact'];

}
